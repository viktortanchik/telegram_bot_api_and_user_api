TOKEN = '2024277284:AAGis5LiCFGpD81TtNA64CkUqvezEegU6pw'
ADMIN = "https://t.me/joinchat/0miZIt7WAYcwM2Y0"
